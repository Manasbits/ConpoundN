import React from 'react';

const Compare = () => {
  return <div>Compare Stocks Page</div>;
};

export default Compare; 