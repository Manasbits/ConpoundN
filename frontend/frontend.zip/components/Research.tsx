import React from 'react';

const Research = () => {
  return <div>Research Report Page</div>;
};

export default Research; 