"use client";

import Link from "next/link";
import { Home, BarChart2, Settings } from "lucide-react";

export default function Sidebar() {
  return (
    <aside className="w-64 bg-white border-r border-gray-200 h-screen">
      <nav className="p-4 space-y-2">
        <Link 
          href="/chat" 
          className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg text-black"
        >
          <span>Chat with Any Stock</span>
        </Link>
        
        <Link 
          href="/research" 
          className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg text-black"
        >
          <span>Research Report</span>
        </Link>
        
        <Link 
          href="/compare" 
          className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-lg text-black"
        >
          <span>Compare Stocks</span>
        </Link>
      </nav>
    </aside>
  );
}