import React from 'react';

const Chat = () => {
  return <div>Chat with Any Stock Page</div>;
};

export default Chat; 