// app/dashboard/chat/page.tsx
export default function ChatPage() {
    return (
      <div>
        <h1>Chat with Any Stock</h1>
        <p>This is the chat page.</p>
        {/* Add your chat functionality here */}
      </div>
    );
  }